#include "header.h"

int main() {
    std::cout << "Hello, World!" << std::endl;
    return 0;
}